# Flags War: DOOM Arena — Android app project

This project packages the supplied HTML game inside a fullscreen Android WebView. The game is bundled locally and does not need hosting to open.

## Build an APK
1. Install Android Studio on a computer and let it install Android SDK Platform 35 and Android Gradle Plugin dependencies.
2. Open this `FlagsWarAPK` folder in Android Studio.
3. Wait for Gradle Sync to finish.
4. Choose **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. Android Studio will show the output location, normally `app/build/outputs/apk/debug/app-debug.apk`.

## Notes
- App name: Flags War: DOOM Arena
- Package ID: `com.crazygames.flagswar`
- Minimum Android: 6.0 (API 23)
- Landscape, fullscreen game view.
- YouTube Live API/chat integration still requires a valid API key and the relevant YouTube setup; this wrapper does not bypass those requirements.
